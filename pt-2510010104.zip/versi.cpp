// Program kedua: membuktikan compiler meamakai standar C++20.
// Nilai __cplusplus untuk c++20 adalah 202002.
#include <iostream>

int main () {
    std::cout << "Halo, Pemrogramaan Terstruktur\n";
    std::cout << "Standar bahasa yang dipakai compiler: " << __cplusplus << "\n";
    return 0;
}