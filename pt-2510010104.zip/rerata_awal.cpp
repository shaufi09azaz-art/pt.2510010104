#include <iostream>
#include <iomanip>

int main() {
    int tugas = 80;
    int uts = 75;
    int uas = 90;

    // TODO 1: hitung jumlah ketiga nilai
    int jumlah = tugas + uts + uas;

    // TODO 2: hitung rata-rata
    double rerata = static_cast<double>(jumlah) / 3;

    // TODO 3: cetak hasil dengan dua angka di belakang koma
    std::cout << "Jumlah : " << jumlah << "\n";
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "Rata-rata: " << rerata << "\n";

    return 0;
}
